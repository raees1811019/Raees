let loder = document.getElementById("webPageLoder");

window.addEventListener("load", function() {
 loder.style.display = "none";
})