// about page function
const aboutPage = document.getElementById("aboutPage");
const menuBar = document.getElementById("menuBar");
const aboutP = document.getElementById("aboutP");

aboutP.onclick = function(){
 userClick = aboutPage.style.display = "block";
 userClick = menuBar.style.display = "none";
}

// about page close function 
const closeAbout = document.getElementById("closeAbout");

closeAbout.onclick = function(){
 userClick = aboutPage.style.display = "";
userClick = menuBar.style.display = "";
}



let loder = document.getElementById("webPageLoder");

window.addEventListener("load", function(){
loder.style.display = "none";

})

// profile drop-down form fill up users

 const profileBtn = document.getElementById("profileBtn");
 
const backBtn = document.getElementById("backBtn");

const profileContener = document.getElementById("profileContener");
let userClick;

profileBtn.onclick = function(){
 userClick = profileContener.style.display = "block";
}

backBtn.onclick = function(){
 userClick = profileContener.style.display = "";
}